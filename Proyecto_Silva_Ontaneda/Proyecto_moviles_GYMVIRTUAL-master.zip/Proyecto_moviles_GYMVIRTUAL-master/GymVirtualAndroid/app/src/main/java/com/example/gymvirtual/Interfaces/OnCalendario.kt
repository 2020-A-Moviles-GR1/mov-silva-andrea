package com.example.gymvirtual.Interfaces

interface OnCalendario{
    fun onCalendarioItemClick(position:Int)
}