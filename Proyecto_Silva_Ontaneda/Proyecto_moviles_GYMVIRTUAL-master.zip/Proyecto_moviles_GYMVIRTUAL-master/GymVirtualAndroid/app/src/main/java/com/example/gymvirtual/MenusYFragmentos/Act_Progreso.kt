package com.example.gymvirtual.MenusYFragmentos

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.gymvirtual.R
/*import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.utils.ColorTemplate*/

/*class Act_Progreso : AppCompatActivity() {
    lateinit var graficas:BarChart
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_act__progreso)
        graficas=findViewById(R.id.grafica)
        var entradas= arrayListOf<BarEntry>()
        entradas.add(BarEntry(0f,2f))
        entradas.add(BarEntry(1f,4f))
        entradas.add(BarEntry(2f,6f))
        entradas.add(BarEntry(3f,8f))
        entradas.add(BarEntry(4f,3f))
        entradas.add(BarEntry(5f,1f))

        var datos:BarDataSet= BarDataSet(entradas,"Gráfica Progreso")

        var data:BarData= BarData(datos)
        datos.setColors(ColorTemplate.COLORFUL_COLORS);
        data.setBarWidth(0.9f)
        graficas.setData(data)
        graficas.setFitBars(true)
    }
}

private fun BarDataSet.setColors(colorfulColors: IntArray?) {
    TODO("Not yet implemented")
}
*/