package com.example.gymvirtual.Modelo

class UsuarioRutinaHttp (
    var id:Int,
    var nombre_usu:String?,
    var edad_usu:String?,
    var peso_usu:String?,
    var altura_usu: String?,
    var correo_usu: String?,
    var sexo_usu: String?
)