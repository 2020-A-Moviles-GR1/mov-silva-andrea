package com.example.gymvirtual.Interfaces

interface goRecetas{
    fun goRecetasItemClick(position:Int)
}